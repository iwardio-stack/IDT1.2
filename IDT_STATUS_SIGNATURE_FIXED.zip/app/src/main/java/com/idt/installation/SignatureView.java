package com.idt.installation;

import android.content.Context;
import android.graphics.*;
import android.view.*;

public class SignatureView extends View {
    private final Paint paint = new Paint();
    private final Path path = new Path();
    private Bitmap bitmap;
    private boolean locked = false;
    public SignatureView(Context context) { this(context, null); }
    public SignatureView(Context context, android.util.AttributeSet attrs) {
        super(context, attrs);
        paint.setColor(Color.BLACK); paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(5f); paint.setStrokeCap(Paint.Cap.ROUND);
        setBackgroundColor(Color.WHITE);
    }
    protected void onDraw(Canvas canvas) { super.onDraw(canvas); if(bitmap!=null) canvas.drawBitmap(bitmap,null,new Rect(0,0,getWidth(),getHeight()),paint); else canvas.drawPath(path, paint); }
    public boolean onTouchEvent(MotionEvent e) {
        if (locked) return false;
        float x=e.getX(), y=e.getY();
        if(e.getAction()==MotionEvent.ACTION_DOWN){path.moveTo(x,y);invalidate();return true;}
        if(e.getAction()==MotionEvent.ACTION_MOVE){path.lineTo(x,y);invalidate();return true;}
        return true;
    }
    public void clear(){ if(!locked){path.reset(); bitmap=null; invalidate();} }
    public void setLocked(boolean value){ locked=value; invalidate(); }
    public boolean isLocked(){ return locked; }
    public void setBitmap(Bitmap source){
        bitmap = source == null ? null : source.copy(Bitmap.Config.ARGB_8888, true);
        path.reset();
        invalidate();
    }

    public void clearAndLock(){
        path.reset();
        bitmap = null;
        locked = true;
        invalidate();
    }
    public Bitmap getBitmap(){
        Bitmap b=Bitmap.createBitmap(getWidth(),getHeight(),Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(b); c.drawColor(Color.WHITE); if(bitmap!=null)c.drawBitmap(bitmap,null,new Rect(0,0,getWidth(),getHeight()),paint); else c.drawPath(path,paint); return b;
    }
}
